import React, { Component } from 'react'
import "./Register.css"

import axios from 'axios';
import EmpLogin from './EmpLogin';

export default class Register extends Component {
constructor(props)
{
        super(props);
        this.state={
            EmployeePassword:"",
            FullName:"",
            EmployeeEmailId:"",
            EmployeeMobileNo:"",
            EmployeeDoj:"",
            EmployeeDept:"",
            ManagerId:""

        }
        this.Addnew=this.Addnew.bind(this);
        this.handleChange=this.handleChange.bind(this);

}
handleChange(e)
{
    this.setState(e);
}
Addnew()
{
    let url="http://localhost:20969/api/Employee";
    axios.post(url,{
        FullName:this.state.FullName,
        EmployeePassword:this.state.EmployeePassword,
        EmployeeEmailId:this.state.EmployeeEmailId,
        EmployeeMobileNo:this.state.EmployeeMobileNo,
        EmployeeDoj:this.state.EmployeeDoj,
        EmployeeDept:this.state.EmployeeDept,
        ManagerId:this.state.ManagerId
    }).then(response=>{
        alert("Registration Completed Successfully");
        window.location="./EmpLogin";
    }).catch(err=>{
        alert(err);
    })
    
}
 
    render() {

        return (
            
            
            <div className="background">
            <div  >
                
                
                <form className="box" >
                <h2 className="h2">Registration</h2>
                   <div >
                       
                        {/* <lable className="lable"> Id</lable> */}
                        {/* <input type="number" name="EmployeeId" placeholder=" Enter your id"></input>
                        <br/> */}
                        <label>FullName</label>
                        <input type="text" name="FullName" onChange={(e)=>this.handleChange({FullName:e.target.value})} placeholder=" Enter your Name"></input>
                        <br/>
                        <label>Password</label>
                        <input type="password" name="EmployeePassword" onChange={(e)=>this.handleChange({EmployeePassword:e.target.value})} placeholder=" Enter your password"></input>
                        <br/>
                        <label>EmailId</label>
                        <input type="emailid" name="EmployeeEmailId" onChange={(e)=>this.handleChange({EmployeeEmailId:e.target.value})}placeholder=" Enter your EmailId"></input>
                        <br/>
                        <label>MobileNo</label>
                        <input type="text" name="EmployeeMobileNo" onChange={(e)=>this.handleChange({EmployeeMobileNo:e.target.value})} placeholder=" Enter your Mobile number"></input>
                        <br/>
                        <label>Date of joining</label>
                        <input type="date" name="EmployeeDoj" onChange={(e)=>this.handleChange({EmployeeDoj:e.target.value})}placeholder=" Enter your Doj" ></input>
                        <br/>
                        <label>Department</label>
                        <input type="text" name="EmployeeDept" onChange={(e)=>this.handleChange({EmployeeDept:e.target.value})} placeholder=" Enter your Department"  ></input>
                        <br/>
                        <label>Manager Id</label>
                        <input type="number" name="ManagerId" onChange={(e)=>this.handleChange({ManagerId:e.target.value})}placeholder=" Enter your ManagerId"></input>
                        <br/>
                        <button type="submit" className="button" onClick={this.Addnew} >Register</button>
                    </div>
                    
                </form>
                
            </div>
            </div>
        )
    }
}
