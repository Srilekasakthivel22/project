import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'
import './LeaveTracker.css';

export default class LeaveTracker extends Component {
    SignOut()
    {
       
        sessionStorage.removeItem("MangId");
        
        sessionStorage.removeItem("email");
        window.location="/EmpLogin";

    }
    Back()
{
    window.location='./EmpDashBoard';
}
    render() {
        return (
            <div className="back">
            <div className="leaf">
                <h1>Attendance Tracker</h1>
                <Link to="/ApplyLeave" >Apply for leave</Link><br></br>
                <Link to="/ViewLeave">View Your Leave Applications</Link>
                <Button variant="primary btn-block" onClick={this.Back} type="submit"> Back to DashBoard </Button>
                <Button variant="primary btn-block" onClick={this.SignOut} type="submit"> SignOut </Button>
            </div>
            </div>
        )
    }
}
