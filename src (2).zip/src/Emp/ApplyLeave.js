import axios from 'axios';
import React, { Component } from 'react'
import './ApplyLeave.css';
import './LeaveTracker';

export default class ApplyLeave extends Component {
    constructor(props)
    {
        super(props);
        this.state={
            Leave:[],
            leaveId:0,
            employeeId:0,
            managerId:0,
            startDate:"",
            endDate:"",
            noOfDays:"",
            leaveType:"",
            leaveReason:"",
            Status:"",
        }
        this.ApplyLeave=this.ApplyLeave.bind(this);
        this.handleChange=this.handleChange.bind(this);
    }
handleChange(e)
{
    this.setState(e);
}
ApplyLeave()
{
    let url="http://localhost:20969/api/Leave";
    axios.post(url,{
        // leaveId:this.state.leaveId,
        employeeId:this.state.employeeId,
        managerId:this.state.managerId,
        status:this.state.startDate,
        endDate:this.state.endDate,
        noOfDays:this.state.noOfDays,
        leaveType:this.state.leaveType,
        leaveReason:this.state.leaveReason,
        status:this.state.status,
    }).then(response=>{
        alert("Leave has been applied Successfully");
        sessionStorage.setItem("Id",response.data.employeeId);
        window.location="./LeaveTracker";
    }).catch(err=>{
        alert(err);
    })
    
}


    render() {

        return (
            <div className="background">
                <div>
                    <form className="box">
                        <h2 className="h2">Apply for leave</h2>
                        <div>
                        {/* <label>LeaveId</label>
                        <input type="Id" name="leaveId" onChange={(e)=>this.handleChange({leaveId:e.target.value})} placeholder=" Enter your LeaveId"></input>
                        <br/> */}
                        <label>EmployeeId</label>
                        <input type="number" name="employeeId" onChange={(e)=>this.handleChange({employeeId:e.target.value})} placeholder=" Enter your EmployeeId"></input>
                        <br/>
                        <label>ManagerId</label>
                        <input type="number" name="managerId" onChange={(e)=>this.handleChange({managerId:e.target.value})} placeholder=" Enter your ManagerId"></input>
                        <br/>
                        <label>StartDate</label>
                        <input type="date" name="startDate" onChange={(e)=>this.handleChange({startDate:e.target.value})} placeholder=" Enter your leave starting date"></input>
                        <br/>
                        <label>EndDate</label>
                        <input type="date" name="endDate" onChange={(e)=>this.handleChange({endDate:e.target.value})} placeholder=" Enter your leave ending date"></input>
                        <br/>
                        <label>No Of days</label>
                        <input type="number" name="noOfDays" onChange={(e)=>this.handleChange({noOfDays:e.target.value})} placeholder=" Enter your leave no of days"></input>
                        <br/>
                        <label>Leave Type</label>
                        <input type="text" name="leaveType" onChange={(e)=>this.handleChange({leaveType:e.target.value})} placeholder=" Enter your leavetype"></input>
                        <br/>
                        <label>Leave Reason</label>
                        <input type="text" name="leaveReason" onChange={(e)=>this.handleChange({leaveReason:e.target.value})} placeholder=" Enter your Reason for leave"></input>
                        <br/>
                        <label>Status</label>
                        <input type="text" name="Status" onChange={(e)=>this.handleChange({status:e.target.value})} placeholder=" Enter your Status"></input>
                        <br/>
                        <button type="submit" className="button" onClick={this.ApplyLeave} >Apply</button>
                        </div>
                    </form>
                </div>
            </div>
        )
    }
}
