import React, { Component } from 'react'

export default class DeleteLeave extends Component {
    render() {
        return (
            <div>
                delete
            </div>
        )
    }
}
