// import React, { Component } from 'react'
// import axios from 'axios';
// import { Await } from 'react-router';


// export default class ApproveOrDeny extends Component {
//     constructor()
//     {
//         super();
//         this.state={
//             Leave:[],
//             leaveId:0,
//             employeeId:0,
//             managerId:0,
//             startDate:"",
//             endDate:"",
//             noOfDays:"",
//             leaveType:"",
//             leaveReason:"",
//             status:"",
//             manangerComment:""
//     render() {
//         return (
//             <div>
                
//             </div>
//         )
//     }
// }
