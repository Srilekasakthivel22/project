import axios from 'axios';
import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'


export default class EmployeesDeatils extends Component {
    constructor()
    {
        super();
        this.state={
            Leave:[],
            
        }
        this.GetLeaveByEmployee=this.GetLeaveByEmployee.bind(this);
        this.SignOut=this.SignOut.bind(this);
    }
    GetLeaveByEmployee(e){
    
        let Id=sessionStorage.getItem("MangId");
        
        axios.get("http://localhost:20969/api/Employee/GetEmpbyMangid?mangId="+Id)
        .then(response=>{
          this.setState({Leave:response.data})
          sessionStorage.setItem("MgId",response.data.managerId);
         
    
      }).catch(error=>{
          console.warn(error)
      })
      console.log()
    }
    SignOut()
    {
        
        sessionStorage.removeItem("MangId");
        sessionStorage.removeItem("Mname");
        sessionStorage.removeItem("email");
        window.location="/ManagerLogin";

    }
   
  
  
componentDidMount()
{
    this.GetLeaveByEmployee();
    let email=sessionStorage.getItem("EmailId");
    let id=sessionStorage.getItem("Id");
    let name=sessionStorage.getItem("Mname")
    if(id==null)
    {
        alert("Pls Login First");
        window.location="/ManagerLogin";
    }
    
}


    render() {
        const {Leave}=this.state;
        return (
            <div>
            <nav>
              
             
            <Button variant="primary btn-block" onClick={this.SignOut} type="submit" > SignOut </Button>
           
           </nav>
            
               <div>ShowAllDetails<div>
            <table className='t' border="1" align='center'>
                <tbody>
                <tr>
                <th>EmployeeId</th>
                <th>EmployeeName</th>
                <th>EmployeeEmail</th>
                <th>EmployeeMobileNumber</th>
                <th>date of join</th>
                <th>Department</th>
                <th>ManagerId</th>
                
                </tr>
                {Leave.map(a => <tr>
                   <td>{a.employeeId}</td>
                    <td>{a.fullName}</td>
                    <td>{a.employeeEmailId}</td>
                    <td>{a.employeeMobileNo}</td>
                    <td>{a.employeeDoj}</td>
                    <td>{a.employeeDept}</td>
                    <td>{a.managerId}</td>
                   
                </tr>
                )}
                </tbody>
               
                
            </table>
            </div>
            </div>
            </div>
        )
    }
}

