import axios from 'axios';
import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'
import "./EditManager";

export default class Profile extends Component {
constructor(props)
{
        super(props);
        this.state={
            Manager:[],
            managerId:"",
            managerPassword:"",
            fullName:"",
            managerEmailId:"",
            managerMobileNo:"",
        

        }
        this.SearchById=this.SearchById.bind(this);
        this.handleChange=this.handleChange.bind(this);
        this.SignOut=this.SignOut.bind(this);
       
}
edit()
{
    window.location="./EditManager";
}
SearchById()
{
    let id=sessionStorage.getItem("MangId");
    let url="http://localhost:20969/api/Manager/"+id;
    axios.get(url).then(response=>{
        this.setState({
            managerId:response.data.managerId,
            managerPassword:response.data.managerPassword,
            fullName:response.data.fullName,
            managerEmailId:response.data.managerEmailId,
            managerMobileNo:response.data.managerMobileNo,
        })
    }).catch(err=>{
        console.warn(err);
    })
    if(id==null)
        {
            alert("Pls Login First");
            window.location="/ManagerLogin";
        }
}
SignOut()
    {
       
        sessionStorage.removeItem("MangId");
        sessionStorage.removeItem("Mangname");
        sessionStorage.removeItem("email");
        window.location="/ManagerLogin";

    }

handleChange(e)
{
    this.setState(e);
}
componentDidMount()
{
    this.SearchById();
   
        
    
}


    render() {
        const {managerId}=this.state;
        const {employeePassword}=this.state;
        const {fullName}=this.state;
        const {managerEmailId}=this.state;
        const {managerMobileNo}=this.state;
        
        return (
            <div className="back">
                <form className="leaf">
                <label>My Details</label><br></br>
             <div className="t"> 
                Id={managerId}<br></br>
                FullName={fullName}<br></br>
                {/* Password={employeePassword}<br></br> */}
                EmailId={managerEmailId}<br></br>
                Mobile number={managerMobileNo}<br></br>
                
                {/* <button type="submit" onClick={this.SearchById}>Profile</button> */}
                <Button variant="primary btn-block" onClick={this.SignOut} type="submit"> SignOut </Button>

                <Button variant="primary btn-block" onClick={this.edit} > Edit My details </Button>
                </div>
                </form>
            </div>
        )
    }
}
