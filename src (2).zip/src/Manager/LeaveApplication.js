import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'
import './LeaveApplication.css';

export default class LeaveApplication extends Component {
    SignOut()
    {
        
        sessionStorage.removeItem("MangId");
        sessionStorage.removeItem("Mangname");
        sessionStorage.removeItem("email");
        window.location="/ManagerLogin";

    }
    componentDidMount()
    {
        let MgId=sessionStorage.getItem("Id");
        let name=sessionStorage.getItem("Mname");
        let email=sessionStorage.getItem("emailid");
        sessionStorage.setItem("Id",MgId);
        sessionStorage.setItem("Mname",name);
        sessionStorage.setItem("emailid",email);
        if(this.email==null)
        {
            alert("Pls Login First");
            window.location="/ManagerLogin";
        }
    }
    

    render() {
        this.email=sessionStorage.getItem("email");
        return (
            <div className="bac">
            
            <div className="l">
                <h1 className="h">LeaveTracker</h1>
               <Link to="/Employeesdetails" className="s">Employee Details</Link><br></br>
               <Link to="/AppOrDeny" className="s">Leave Requests</Link><br></br>
               <Button variant="primary btn-block" onClick={this.SignOut} type="submit" className="s"> SignOut </Button>
            </div>
            </div>
        )
    }
}
